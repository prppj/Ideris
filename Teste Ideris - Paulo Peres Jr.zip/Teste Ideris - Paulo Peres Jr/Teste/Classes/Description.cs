﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IderisTest.Classes
{
    class Description
    {
        public string id { get; set; }
    }
}
