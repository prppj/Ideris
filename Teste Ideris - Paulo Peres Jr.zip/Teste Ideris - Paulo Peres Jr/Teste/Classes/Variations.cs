﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace IderisTest.Classes
{
    class Variations
    {        
        public string id { get; set; }
        public decimal? price { get; set; }
        public List<Attributes> attribute_combinations { get; set; }
        public int available_quantity { get; set; }
        public int sold_quantity { get; set; }
        public List<string> sale_terms { get; set; }
        public List<string> picture_ids { get; set; }
        public string catalog_product_id { get; set; }


    }
}
