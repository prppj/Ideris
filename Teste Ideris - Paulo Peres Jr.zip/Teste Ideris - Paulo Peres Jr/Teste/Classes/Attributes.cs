﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace IderisTest.Classes
{
    class Attributes
    {
        public string id { get; set; }
        public string name { get; set; }
        public string value_id { get; set; }
        public string value_name { get; set; }
        public ValueStruct value_struct { get; set; }
        public List<Values> values { get; set; }
        public string attribute_group_id { get; set; }
        public string attribute_group_name { get; set; }

    }

    public class Values
    {
        public int? id { get; set; }        
        public string nome { get; set; }
        
        [DataMember(Name = "struct")]
        public ValueStruct vstruct { get; set; }


    }
    public class ValueStruct
    {
        public int? number { get; set; }
        public string unit { get; set; }

    }

}
