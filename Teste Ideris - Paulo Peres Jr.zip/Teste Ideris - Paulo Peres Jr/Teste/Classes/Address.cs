﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IderisTest.Classes
{ 
    public class Address
    {
        public string id { get; set; }
        public City city { get; set; }
        public State state { get; set; }
        public Country country { get; set; }
        public SearchLocation search_location { get; set; }


    }
    //Classe Auxiliar
    public class NameId
    {
        public string id { get; set; }
        public string Name { get; set; }
    }

    public class City : NameId { }
    public class State : NameId { }
    public class Country : NameId { }
    public class Neighborhood : NameId { }

    public class SearchLocation
    {
        public Neighborhood neighborhood { get; set; }
        public City city { get; set; }
        public State state { get; set; }
    }















}
