﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IderisTest.Classes
{
    class MlItem
    {
        public string id { get; set; }
        public string site_id { get; set; }
        public string title { get; set; }
        public string subtitle { get; set; }
        public string seller_id { get; set; }
        public string category_id { get; set; }
        public string official_store_id { get; set; }
        public decimal? price { get; set; }
        public decimal? base_price { get; set; }
        public decimal? original_price { get; set; } 
        public string currency_id { get; set; }
        public int initial_quantity { get; set; }
        public int available_quantity { get; set; }
        public int sold_quantity { get; set; }
        public string[] sale_terms { get; set; }
        public string buying_mode { get; set; }
        public string listing_type_id { get; set; }
        public DateTime start_time { get; set; }
        public DateTime stop_time { get; set; }
        public string condition { get; set; }
        public string permalink { get; set; }
        public string thumbnail_id { get; set; }
        public string thumbnail { get; set; }
        public string secure_thumbnail { get; set; }
        public List<Pictures> pictures { get; set; }
        public string video_id { get; set; }
        public List<Description> descriptions { get; set; }
        public bool accepts_mercadopago { get; set; }
        public string[] non_mercado_pago_payment_methods { get; set; }
        public Shipping shipping{ get; set; }
        public string international_delivery_mode { get; set; }
        public Address seller_address { get; set; }
        public string seller_contact { get; set; }
        public Address location { get; set; }
        public List<string> coverage_areas { get; set; }
        public List<Attributes> attributes { get; set; }
        public List<string> warnings { get; set; }
        public string listing_source { get; set; }
        public List<Variations> variations { get; set; }
        public string status { get; set; }
        public List<string> sub_status { get; set; }
        public List<string> tags { get; set; }
        public string warranty { get; set; }
        public string catalog_product_id { get; set; }
        public string domain_id { get; set; }
        public string parent_item_id { get; set; }
        public decimal? differential_pricing { get; set; }
        public List<string> deal_ids { get; set; }
        public bool automatic_relist { get; set; }
        public DateTime date_created { get; set; }
        public DateTime last_updated { get; set; }
        public decimal? health { get; set; }
        public bool catalog_listing { get; set; }
        public List<string> channels { get; set; }





    }
}
