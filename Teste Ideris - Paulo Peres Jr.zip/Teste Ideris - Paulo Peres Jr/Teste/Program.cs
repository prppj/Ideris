﻿using System;
using System.Collections.Generic;
using System.Linq;
using RestSharp;
using Newtonsoft.Json;
using IderisTest.Classes;

/// <summary>
///
/// O Código deve retornar
///     Problema resolvido
///    
/// Não deve ser adicionado nenhum RETURN a mais
///
/// </summary>
/// 

class Program {

    const string apiAddress = "https://api.mercadolibre.com/items/";

    //Nao mexer aqui
    #region Nao mexer aqui
    static void Main(string[] args) {
        Console.WriteLine(Problema());
        Console.ReadLine();
    }
    #endregion
    //
    public static string Problema() {
        try {
            var dados = BuscarInformacoesML();
            if (dados != null && dados.Count() == 4)
                return "Problema resolvido";
            else
                return "Problema com falha";
        } catch (Exception ex) {
            return "Problema com falha";
        }
    }

    /// <summary>
    ///
    ///     Usando RestSharp e Newtonsoft.Json, implemente um método que consulte a api do mercado livre e retorne em um array de "MlItem"
    ///     corrigindo qualquer erro que possa ocorrer
    ///    
    ///     ex https://api.mercadolibre.com/items/MLB832035381    ///     
    ///    
    ///     o metodo deverá retornar os seguintes items:
    ///    
    ///     MLB832035381
    ///     MLB938457671
    ///     MLB691669454
    ///     MLB837523349
    ///
    /// </summary>
    /// <returns></returns>

    private static List<MlItem> BuscarInformacoesML()
    {
        try
        {            
            string[] mlItens = new string[] { "MLB832035381", "MLB938457671", "MLB691669454", "MLB837523349" };
            
            List<MlItem> list = new List<MlItem>();
            {
                foreach (string item in mlItens)
                {
                    RestClient restClient = new RestClient(string.Format("{0}{1}", apiAddress, item));
                    IRestRequest restRequest = new RestRequest(Method.GET);
                    IRestResponse restResponse = restClient.Execute(restRequest);
                    restRequest.AddHeader("Accept", "application/json");

                    if (restResponse.StatusCode != System.Net.HttpStatusCode.BadRequest)
                    {                         
                        list.Add(JsonConvert.DeserializeObject<MlItem>(restResponse.Content));
                    }
                    else
                    {
                        Console.WriteLine("Houve um problema na requisição" + restResponse.ErrorMessage);
                    }
                }
                return list;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception when calling ItemsApi.ItemsIdGet: " + ex.Message);
            Console.WriteLine(ex.StackTrace);
            return null;
        }
    }
}
